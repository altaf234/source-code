function App() {
  return (
    <>
      <nav className="navbar bg-dark">
        <div className="container-fluid">
          <a href="/">
            <h2 className="text-white">Luxe</h2>
          </a>
          <a
            href="/login"
            className="bold btn btn-light border-5 rounded-5 shadow-sm"
            style={{ maxHeight: "50px" }}
          >
            Login
          </a>
        </div>
      </nav>

      <h1 id="moto" className="text-center text-white mt-10">
        Build fast, responsive <br></br>
        <span className="text-warning">websites</span> with Team
      </h1>

      <div className="text-center mt-4">
        <a
          href="/register"
          className="bold btn btn-light btn-lg border-5 rounded-5 shadow-sm"
        >
          Create account
        </a>
      </div>

      <div id="video_pr">
        <iframe
          id="video"
          width="600"
          height="315"
          src="https://www.youtube-nocookie.com/embed/JEPvemObFFM"
          title="YouTube video player"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        ></iframe>
      </div>

      <div className="section-header text-center text-white">
        <h1 className="text">About us</h1>
      </div>

      <div className="flex-body">
        <div className="flex-item glass" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content">
            <h2 className="glass-heading">Build with team</h2>
            <p className="glass-body">
              Making website/app alone is very hard we know your problem thats
              why we built Luxe. Using Luxe you can build website/app with team
              and collaborate in real time for free.
            </p>
          </div>
        </div>
        <div className="flex-item glass" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content">
            <h2 className="glass-heading">Save your work</h2>
            <p className="glass-body">
              Access Luxe cloud storage free fast and secure, save your work in
              cloud with 5 GB free space upload on github and share with friends
              for free.
            </p>
          </div>
        </div>
      </div>
      <div className="flex-body">
        <div className="flex-item glass" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content">
            <h2 className="glass-heading">CEO and CTO</h2>
            <p className="glass-body quoted">
              Making website/app from scratch is very hard specialy if your
              individual thats why build Luxe to help you make website/app in a
              minute. It is simple and very easy to use.
            </p>
          </div>
        </div>
      </div>

      <div className="section-header text-center text-white">
        <h1 className="text">Pricing</h1>
      </div>

      <div className="flex-body">
        <div className="flex-item glass blue" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content with-description">
            <h2 className="glass-heading text-center">Free</h2>
            <p className="glass-description text-center">Free forever</p>
            <div className="glass-body">
              <div className="lists">
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  5GB cloud storage
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  2 collaborations
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  Lifetime access of software
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  Community support only
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex-item glass blue" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content with-description">
            <h2 className="glass-heading text-center">Paid</h2>
            <p className="glass-description text-center">Pay as you go</p>
            <div className="glass-body full-center">
              <div className="lists">
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  Unlimited cloud storage
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  Unlimited collaborations
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  Lifetime access of software
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  24×7 live support
                </div>
                <div className="list">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-check2"
                    viewBox="0 0 16 16"
                  >
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"></path>
                  </svg>
                  community support
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section-header text-center text-white">
        <h1 className="text">Beta</h1>
      </div>

      <a
        className="flex-body"
        href="https://docs.google.com/forms/d/e/1FAIpQLSdy5dIbD-9eccrDV8S3itDDZcx9bSLdKV-UjHIZkGAcc5ThVQ/viewform?usp=sf_link"
      >
        <div className="flex-item glass red" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content">
            <h2 className="glass-heading text-center">Beta</h2>
            <div className="glass-body text-center">
              <p className="text-center">
                Join beta program and get exclusive content for free
              </p>
              <button className="btn btn-light rounded-5 bold">JOIN</button>
            </div>
          </div>
        </div>
      </a>

      <div className="section-header text-center text-white">
        <h1 className="text">Login</h1>
      </div>

      <a className="flex-body mb-5" href="/login">
        <div className="flex-item glass" data-tilt data-tilt-max="5">
          <div className="glass-border"></div>
          <div className="glass-content">
            <h2 className="glass-heading text-center">Login</h2>
            <div className="glass-body text-center">
              <form style={{ maxWidth: "350px", margin: "auto" }}>
                <div className="form-floating mb-3">
                  <input
                    type="email"
                    className="form-control"
                    id="floatingInput"
                    placeholder="name@example.com"
                  />
                  <label htmlFor="floatingInput">Email address</label>
                </div>
                <div className="form-floating mb-3">
                  <input
                    type="password"
                    className="form-control"
                    id="floatingPassword"
                    placeholder="Password"
                  />
                  <label htmlFor="floatingPassword">Password</label>
                </div>
                <button type="submit" className="btn btn-light rounded-5 bold">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </a>
    </>
  );
}

export default App;
