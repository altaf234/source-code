# snake game
## About
A snake game written in [rust](https://www.rust-lang.org/).
Try it [here](https://eurine.github.io/snake-game)
