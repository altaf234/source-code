# 2d-multiplayer-game
A 2d top down multiplayer game made with javascript and firebase. Try it [here](https://a-rustacean.github.io/2d-multiplayer-game).
