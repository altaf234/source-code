export default class Bullet {
  constructor(player, img) {
    this.width = 30;
    this.height = 30;
    this.top = {
      width: 4,
      height: 2.5,
    };

    this.smallTop = {
      width: 2,
      height: 1.5,
    };

    this.speed = 80;

    this.position = {
      x: player.position.x + player.width / 2 - this.width / 2,
      y: player.position.y - 25,
    };

    this.img = img;
  }

  draw(ctx) {
    ctx.drawImage(
      this.img,
      this.position.x,
      this.position.y,
      this.width,
      this.height
    );
  }

  update(deltaTime) {
    if (!deltaTime) return;
    this.position.y -= this.speed / deltaTime;
  }
}
