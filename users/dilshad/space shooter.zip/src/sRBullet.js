export default class SRBullet {
  constructor(bullet, img) {
    this.width = 15;
    this.height = 15;

    this.top = {
      width: 4,
      height: 2.5,
    };

    this.smallTop = {
      width: 2,
      height: 1.5,
    };

    this.speed = 80;

    this.position = {
      x: bullet.position.x + bullet.width / 2 - this.width / 2 + 15,
      y: bullet.position.y + bullet.height / 2 - this.height / 2,
    };

    this.img = img;
  }

  draw(ctx) {
    ctx.drawImage(
      this.img,
      this.position.x,
      this.position.y,
      this.width,
      this.height
    );
  }

  update(deltaTime) {
    if (!deltaTime) return;
    this.position.y -= this.speed / deltaTime;
  }
}
